﻿using Presentation;
namespace CRUDwithORM_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Display display = new Display();
        }
    }
}